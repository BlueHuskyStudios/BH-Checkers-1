import java.io.*;
import java.util.*;
import javax.swing.*;

public class GameScore
{
  public static String tryScore(String fileName, String username, int win, int lose) throws IOException
  {
    if (addScore(fileName, username, win, lose).equalsIgnoreCase("Username already exists."))
    {
      System.err.println("Changing score of " + username + ".");
      changeScore(fileName, username, win, lose);
    }
    
    else
      addScore(fileName, username, win, lose);
    return "Score added/changed";
  }//END tryScore METHOD
  
  public static String changeScore(String fileName, String username, int win, int lose) throws IOException
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        if (usernames[i] == username)
        {
          if (YesNoBox.bool("Unexpected glitch when reading " + usernames[i] + "'s scores.\nThey may not be present. Would you like to reset " + usernames[i] + "'s scores in the file \"" + fileName + "\" to " + win + " wins and " + lose + " losses?\n\n(NOTE: The file is corrupt and the program you are trying to use may not work without resetting these scores. It is reccommended that you click Yes)", "Error from GameScore", 0))
          {
            wins[i] = win;
            losses[i] = lose;
          }
        }
        else if (YesNoBox.bool("Unexpected glitch when reading " + usernames[i] + "'s scores.\nThey may not be present. Would you like to reset " + usernames[i] + "'s scores in the file \"" + fileName + "\" to 0 wins and 0 losses?\n\n(NOTE: The file is corrupt and the program you are trying to use may not work without resetting these scores. It is reccommended that you click Yes)", "Error from GameScore", 0))
        {
          wins[i] = 0;
          losses[i] = 0;
        }
        else
          JOptionPane.showMessageDialog(null,"CAUTION: This program may not work if this file is corrupt. You are warned.", "WARNING from GameScore", 0);
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
      {
        wins[i] += win;
        losses[i] += lose;
        break;
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      fileContents += usernames[i] + "\t" + wins[i] + " " + losses[i] + "\r\n";
    }
    
    
    //System.out.println(fileContents);
    FileWriter writeToFile = new FileWriter(fileName);
    FileWriter addToFile = new FileWriter(fileName, true);
    writeToFile.write("//BEGIN\r\n" + fileContents + "//END");
    writeToFile.close();
    return "Scores successfully changed.";
  }//END changeScore METHOD
  
  
  public static String addScore(String fileName, String username, int win, int lose) throws IOException
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        if (YesNoBox.bool("Unexpected glitch when reading " + usernames[i] + "'s scores.\nThey may not be present. Would you like to reset " + usernames[i] + "'s scores in the file \"" + fileName + "\" to 0 wins and 0 losses?\n\n(NOTE: The file is corrupt and the program you are trying to use may not work without resetting these scores. It is reccommended that you click Yes)", "Error from GameScore", 0))
        {
          wins[i] = 0;
          losses[i] = 0;
        }
        else
          JOptionPane.showMessageDialog(null,"CAUTION: This program may not work if this file is corrupt. You are warned.", "WARNING from GameScore", 0);
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
      {
        System.err.println("Username already exists.");
        return ("Username already exists.");
      }
    }
    
    
    for (i=0; i < fileLength; i++)
    {
      fileContents += usernames[i] + "\t" + wins[i] + " " + losses[i] + "\r\n";
    }
    
    fileContents += username + "\t" + win + " " + lose + "\r\n";
    
    //System.out.println(fileContents);
    FileWriter writeToFile = new FileWriter(fileName);
    FileWriter addToFile = new FileWriter(fileName, true);
    writeToFile.write("//BEGIN\r\n" + fileContents + "//END");
    writeToFile.close();
    return ("Score successfully added.");
  }//END addScore METHOD
  
  public static String getScore(String fileName, String username) throws IOException
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0, win = -1, lose = -1;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        changeScore(fileName, usernames[i], 0, 0);
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
      {
        win = wins[i];
        lose = losses[i];
        break;
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
        break;
    }
    if (i == fileLength)
    {
      System.err.println("No such username!");
      return ("No such username!");
    }
    return (win + " " + lose);
  }//END getScore METHOD
  
  public static int getWins(String fileName, String username) throws IOException, NameNotFoundException, ValueGlitch
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0, win = -1, lose = -1;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return -1337;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        changeScore(fileName, usernames[i], 0, 0);
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
      {
        win = wins[i];
        lose = losses[i];
        break;
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
        break;
    }
    if (i == fileLength)
    {
      throw new NameNotFoundException(username);
    }
    return (win);
  }//END getLosses METHOD
  
  public static int getLosses(String fileName, String username) throws IOException, NameNotFoundException
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0, win = -1, lose = -1;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return -1337;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        changeScore(fileName, usernames[i], 0, 0);
      }
    }
    
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
      {
        win = wins[i];
        lose = losses[i];
        break;
      }
    }
    
    for (i=0; i < fileLength; i++)
    {
      if (usernames[i].equalsIgnoreCase(username))
        break;
    }
    if (i == fileLength)
    {
      throw new NameNotFoundException(username);
    }
    return (lose);
  }//END getLosses METHOD
  
  public static String allScores(String fileName) throws IOException
  {
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0, win = -1, lose = -1;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        changeScore(fileName, usernames[i], 0, 0);
      }
    }
    
    fileContents = "Username\t Wins\t Losses\n";
    for (i=0; i < fileLength; i++)
    {
      fileContents += (i + 1 + ": " + usernames[i] + (usernames[i].length() < 5 ? "\t\t" : "\t ") + wins[i] + "\t " + losses[i] + "\n");
    }
    
    return (fileContents);
  }//END allScores METHOD
  
  public static String sortScores(String fileName) throws IOException
  {
    Scanner scan;
    String[] usernames, oUser;
    int[] wins, losses, order, oWin, oLose;
    int fileLength = 0, highScore = 0;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    order = new int[fileLength];
    oUser = new String[fileLength];
    oWin = new int[fileLength];
    oLose = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        System.err.println(wins[i] + " " + losses[i]);
        changeScore(fileName, usernames[i], (wins[i] != 0 ? wins[i] : 0), (losses[i] != 0 ? losses[i] : 0));
      }
    }
    
    return ("Scores successfully sorted.");
  }//END sortScores METHOD
  
  public static String topScores(String fileName, int scores) throws IOException
  {
    sortScores(fileName);
    
    Scanner scan;
    String[] usernames;
    int[] wins, losses;
    int fileLength = 0, win = -1, lose = -1;
    try
    {
      scan = new Scanner(new File(fileName));
    }
    catch (FileNotFoundException ex)
    {
      System.err.println("File not found: " + fileName);
      return "File not found: " + fileName;
    }
    
    String fileContents = "", fileLine = scan.nextLine();
    while (!fileLine.equals("//END")) //First sweep gets the length of the file
    {
      fileLine = scan.nextLine();
      if (!fileLine.equals("//END"))
        fileLength++;
    }
    
    usernames = new String[fileLength];
    wins = new int[fileLength];
    losses = new int[fileLength];
    
    scan = new Scanner(new File(fileName)); //RESET THE SCANNER FOR THE SECOND SWEEP
    String spare = scan.next();
    
    int i;
    for (i=0; i < fileLength; i++) //Second sweep makes arrays of all values
    {
      try
      {
        usernames[i] = scan.next();
        //System.out.print(usernames[i]);
        wins[i] = scan.nextInt();
        //System.out.print(wins[i]);
        losses[i] = scan.nextInt();
        //System.out.println(losses[i]);
      }
      catch (InputMismatchException ex)
      {
        System.err.println(wins[i] + " " + losses[i]);
        changeScore(fileName, usernames[i], (wins[i] != 0 ? wins[i] : 0), (losses[i] != 0 ? losses[i] : 0));
      }
    }
    
    fileContents = "Username\t Wins\t Losses\n";
    for (i=0; i < scores; i++)
    {
      fileContents += (i + 1 + ": " + usernames[i] + (usernames[i].length() < 5 ? "\t\t " : "\t ") + wins[i] + "\t " + losses[i] + "\n");
    }
    
    return (fileContents);
  }//END topScores METHOD
}
  