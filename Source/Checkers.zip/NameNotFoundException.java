public class NameNotFoundException extends Exception
{
  NameNotFoundException (String username)
  {
    super ("Cannot find username \"" + username + "\"");
  }
}