public class GameBoard
{
  public static String print(int size, String[][] board)
  {
    String square = "";
    boolean bigCol = false;
    char col = 'A';
    char col2 = 'A';
    int row = 1;
    
    square += ("\n\n  ");
    for (int i=0; i < size; i++)
    {
      if (bigCol)
        square +=(col2);
      else
        square +=(" ");
      
      square +=(col);
      col++;
      
      if (col > 'Z' && !bigCol)
      {
        bigCol = true;
        col = 'A';
      }
      if (col > 'Z' && bigCol)
      {
        col = 'A';
        col2++;
      }
      square +=("  ");
    }
    square +=("\n");
    
    for (int i=0; i < size; i++)
    {
      if (i < 10)
        square += (" " + (i + 1));
      else
        square += (i + 1);
      
      for (int j=0; j < size; j++)
      {
        square += (" " + board[i][j] + " ");
        if (j < (size - 1))
          square += ("|");
      }
      square +=("\n");
      
      if (i < 10)
        square += ("  ");
      else
        square += (" ");
      
      if (i < (size - 1))
      {
        for (int j=0; j < size; j++)
        {
          square += ("---");
          if (j < size - 1)
            square += ("+");
        }
        square +=("\n");
      }
    }
    return square;
  }
  
  public static String print(int size, char[][] board)
  {
    String square = "";
    boolean bigCol = false;
    char col = 'A';
    char col2 = 'A';
    int row = 1;
    
    square += "\n\n  ";
    for (int i=0; i < size; i++)
    {
      if (bigCol)
        square +=(col2);
      else
        square +=(" ");
      
      square +=(col);
      col++;
      
      if (col > 'Z' && !bigCol)
      {
        bigCol = true;
        col = 'A';
      }
      if (col > 'Z' && bigCol)
      {
        col = 'A';
        col2++;
      }
      square +=("  ");
    }
    square +=("\n");
    
    for (int i=0; i < size; i++)
    {
      if (i < 10)
        square += (" " + (i + 1));
      else
        square += (i + 1);
      
      for (int j=0; j < size; j++)
      {
        square += (" " + board[i][j] + " ");
        if (j < (size - 1))
          square += ("|");
      }
      square +=("\n");
      
      if (i < 10)
        square += ("  ");
      else
        square += (" ");
      
      if (i < (size - 1))
      {
        for (int j=0; j < size; j++)
        {
          square += ("---");
          if (j < size - 1)
            square += ("+");
        }
        square +=("\n");
      }
    }
    return square;
  }
}