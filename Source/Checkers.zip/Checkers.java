/* Plays Checkers
 * 
 * Version: 0.0.8
 * Originally created by Supuhstar on 2010/02/15
 * Latest version finished on 2010/03/16
 * 
 * Copyright Blue Husky Studios, � 2010 under Creative Commons 3.0 (CC-BY-SA)
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;

public class Checkers
{
  private static boolean move = true, owner, quit = false, winner = false;
  private static char mark, notMark, mark1 = 'b', mark2 = 'r', where, EMPTY = ' ';
  private static char[][] board;
  private static int turns = 0, to1, to2, from1, from2, pieces1 = 0, pieces2 = 0, piece, notPiece, p1wins = 0, p2wins = 0;
  private static String square = "", spareStr = "", error, header;
  private static final int SIZE = Integer.parseInt(JOptionPane.showInputDialog(null, "size?", 8));
  private static final String TITLE = "Blue Husky's Checkers", VERSION = "0.0.8", SAVEFILE = "CheckersSave.dll";
  
  public static void main(String[] args)
  {
    boolean move = true, quit = false, winner = false;
    char mark1 = 'b', mark2 = 'r', EMPTY = ' ';
    int turns = 0, pieces1 = 0, pieces2 = 0, p1wins = 0, p2wins = 0;
    String square = "", spareStr, color, color1 = "black", color2 = "red";
  
    JOptionPane.showMessageDialog(null, "Welcome to " + TITLE + ". Please follow the instructions and enjoy your game.", TITLE + " " + VERSION, -1);
    
    while (!quit)
    {
      color1 = JOptionPane.showInputDialog(null, "What is your color, Player 1? (press Enter or OK for default)", TITLE, 3);
      if (color1 == null)
      {
        quit = YesNoBox.bool("Are you sure you want to quit?", TITLE, 0);
        if (quit)
          break;
      }
      else if ((color1 != null && color1 != "" && color1.length() != 0) && !(color1.charAt(0) >= 'A' && (color1.charAt(0) <= 'Z')) && !(color1.charAt(0) >= 'a' && (color1.charAt(0) <= 'z')))
      {
        JOptionPane.showMessageDialog(null, "Please type a color that starts with a letter. (As far as I know, that's all of them)", "Error - " + TITLE, 0);
      }
      else
        break;
    }
    if (color1 != null && color1 != "" && color1.length() != 0)
      mark1 = color1.charAt(0);
    
    if (mark1 >= 'A' && mark1 <= 'Z')
      mark1 = (char)((int)mark1 + 32);
    
    //System.out.println ("Player 1's mark set to " + mark1 + ".");///////////////////////////////////////////////////TESTING CODE
    
    while (!quit)
    {
      color2 = JOptionPane.showInputDialog(null, "What is your color, Player 2? (press Enter or OK for default)", TITLE, 3);
      if (color2 == null)
      {
        quit = YesNoBox.bool("Are you sure you want to quit?", TITLE, 0);
        if (quit)
          break;
      }
      else if ((color2 != null && color2 != "" && color2.length() != 0) && !(color2.charAt(0) >= 'A' && (color2.charAt(0) <= 'Z')) && !(color2.charAt(0) >= 'a' && (color2.charAt(0) <= 'z')))
      {
        JOptionPane.showMessageDialog(null, "Please type a color that starts with a letter. (As far as I know, that's all of them)", "Error - " + TITLE, 0);
      }
      else if ((color2.equals("") && mark2 != mark1) || color2 == null || color2.length() == 0)
        break;
      else
      {
        if (color2.charAt(0) == mark1 || color2.charAt(0) == mark1 - 32)
          JOptionPane.showMessageDialog(null, "Player 1's color starts with \"" + mark1 + "\". Please choose a color that starts\nwith a different letter.", "Error - " + TITLE, 0);
        else
          break;
      }
    }
    if (color2 != null && !color2.equals("") && color2.length() != 0)
      mark2 = color2.charAt(0);
    
    if (mark2 >= 'A' && mark2 <= 'Z')
      mark2 = (char)(mark2 + 32);
    
    //System.out.println ("Player 2's mark set to " + mark2 + ".");///////////////////////////////////////////////////TESTING CODE
    
    
    
    board = new char[SIZE][SIZE];
    
    while (!quit)
    {System.out.println(1);
      pieces1 = 0;
      pieces2 = 0;
      for (int i=0; i < SIZE; i++) //SETS ALL SQUARES AS EMPTY
      {
        for (int j=0; j < SIZE; j++)
          board[i][j] = (EMPTY);
      }
      
      for (int i=0; i < (SIZE / 2) - 1; i++) //SETS PLAYER 2'S PIECES
      {
        for (int j=1; j < SIZE; j++, j++)
        {
          if (j == 1 && i == 1)
            j--;
          board[i][j] = mark2;
          pieces2++;
        }
      }
      
      for (int i=SIZE; i > SIZE - ((SIZE / 2) - 1); i--) //SETS PLAYER 1'S PIECES
      {
        for (int j=0; j < SIZE; j++, j++)
        {
          if (j == 0 && i == SIZE - 1)
            j++;
          board[i - 1][j] = mark1;
          pieces1++;
        }
      }
      
      //BEGIN GAME
      while (!winner && !quit)
      {//System.out.println(2);///////////////////////////////////////////////////////////////////////////////////////TESTING CODE
        //System.out.print("\n  ");
        for (turns=0; !quit && pieces1 > 0 && pieces2 > 0; turns++)
        {//System.out.println(3);/////////////////////////////////////////////////////////////////////////////////////TESTING CODE
          //System.out.println(mark1 + "'s: " + pieces1 + "\n" + mark2 + "'s: " + pieces2);///////////////////////////TESTING CODE
          if (move)
            owner = true;
          else
            owner = false;
          
          //BEGIN BOARD CREATION
          System.out.print(GameBoard.print(SIZE, board));
          //END BOARD CREATION
          
          
          //BEGIN PLAYER TURN
          if (move)
          {
            mark = mark1;
            notMark = mark2;
            piece = pieces1;
            notPiece = pieces2;
            color = color1;
            header = "Player 1's turn";
          }
          else
          {
            mark = mark2;
            notMark = mark1;
            piece = pieces2;
            notPiece = pieces1;
            color = color2;
            header = "Player 2's turn";
          }
          
          where = 32;
          to1 = 0;
          to2 = 0;
          from1 = 0;
          from2 = 0;
          spareStr = "";
          boolean delimHit;
          error = "";
          while (true)
          {//System.out.println(4);///////////////////////////////////////////////////////////////////////////////////TESTING CODE
            spareStr = JOptionPane.showInputDialog(null, error + "Which piece are you going to move, Player " + (move ? "1" : "2") + "?", header + " - " + TITLE, 3);
            if (spareStr == null)
            {
              quit = YesNoBox.bool("Are you sure you want to forfeit?", "End game? - " + TITLE, 0);
              if (quit)
                break;
            }
            else if (spareStr.length() < 2)
            {
              //System.err.print("I'm sorry, but that is the incorrect format.  be sure that it is typed like this: \"LETTER NUMBER\", with only a space between them (Example: \"A 1\"). Try placing your " + color + " piece again.\n  ");
              JOptionPane.showMessageDialog(null, "I'm sorry, but that is the incorrect format.  be sure that it is typed like this: \"LETTER NUMBER\", with only a space between them (Example: \"A 1\"). Try placing your " + color + " piece again.", "Error - " + TITLE, 0);
            }
            else
            {
              for (int i=0; i < spareStr.length(); i++)
              {
                if (spareStr.charAt(i) >= '0' && spareStr.charAt(i) <= '9'&& spareStr.charAt(i) >= 'a' && spareStr.charAt(i) <= 'z' && spareStr.charAt(i) >= 'A' && spareStr.charAt(i) <= 'Z')
                  delimHit = true;
                else
                  delimHit = false;
                
                if (!delimHit)
                {
                  if (spareStr.charAt(i) >= '0' && spareStr.charAt(i) <= '9')
                    from1 = Integer.parseInt(spareStr.charAt(i) + "") - 1;
                  else if (spareStr.charAt(i) >= 'a' && spareStr.charAt(i) <= 'z')
                    from2 = (int)spareStr.charAt(i) - 97;
                  else if (spareStr.charAt(i) >= 'A' && spareStr.charAt(i) <= 'Z')
                    from2 = (int)spareStr.charAt(i) - 65;
                }
              }
              if (!(board[from1][from2] == mark || board[from1][from2] == (char)(mark - 32)))
              {
                //System.err.print("I'm sorry, but there is not a \"" + mark + "\" there. Please choose a square with a \"" + mark + "\".\n  ");
                JOptionPane.showMessageDialog(null, "I'm sorry, but there is not a " + color + " piece there. Please choose a square with one.", "Error - " + TITLE, 0);
              }
              else
              {
                spareStr = JOptionPane.showInputDialog(null, error + "To where do you want to move this \"" + board[from1][from2] + "\"?", header + " - " + TITLE, 3);
                if (spareStr == null || spareStr == "")
                {
                  quit = YesNoBox.bool("Are you sure you want to forfeit?", "End game? - " + TITLE, 0);
                  if (quit)
                    break;
                }
                else if (spareStr.length() < 2)
                {
                  //System.err.print("I'm sorry, but that is the incorrect format.  be sure that it is typed like this: \"LETTER NUMBER\", with only a space between them (Example: \"A 1\"). Try placing your \"" + mark + "\" again.\n  ");
                  JOptionPane.showMessageDialog(null, "I'm sorry, but that is the incorrect format.  be sure that it is typed like this: \"LETTER NUMBER\", with only a space between them (Example: \"A 1\"). Try placing your \"" + mark + "\" again.", "Error - " + TITLE, 0);
                }
                else
                {
                  for (int i=0; i < spareStr.length(); i++)
                  {
                    if (spareStr.charAt(i) == ' ')
                      delimHit = true;
                    else
                      delimHit = false;
                    
                    if (!delimHit)
                    {
                      if (spareStr.charAt(i) >= '0' && spareStr.charAt(i) <= '9')
                        to1 = Integer.parseInt(spareStr.charAt(i) + "") - 1;
                      else if (spareStr.charAt(i) >= 'a' && spareStr.charAt(i) <= 'z')
                        to2 = (int)spareStr.charAt(i) - 97;
                      else if (spareStr.charAt(i) >= 'A' && spareStr.charAt(i) <= 'Z')
                        to2 = (int)spareStr.charAt(i) - 65;
                    }
                  }
                  if (to1 < 0 || to1 > SIZE || to2 < 0 || to2 > SIZE)
                    JOptionPane.showMessageDialog(null, "Can't move to a space outside the board", "Illegal move! - " + TITLE, 0);
                  //System.err.println("((" + move + " && (" + (to1 > from1) + ")) || (" + !move + " && (" + (to1 < from1) + "))) && !(" + (board[from1][to1] >= 'A') + " && " + (board[from1][to1] <= 'Z') + ")");
                  //System.err.println("((" + move + " && " + (to1 > from1) + ") || (" + !move + " && " + (to1 < from1) + ") && " + !((board[from1][to1] >= 'A') && (board[from1][to1] <= 'Z')));
                  //System.err.println("(" + (move && (to1 > from1)) + " || " + (!move && (to1 < from1)) + ") && " + !((board[from1][to1] >= 'A') && (board[from1][to1] <= 'Z')));
                  //System.err.println("(" + ((move && ((to1 > from1))) || (!move && (to1 < from1))) + ") && " + !((board[from1][to1] >= 'A') && (board[from1][to1] <= 'Z')));
                  //System.err.println(((move && ((to1 > from1))) || (!move && (to1 < from1))) && (!((board[from1][to1] >= 'A') && (board[from1][to1] <= 'Z'))));
                  else if (((move && (to1 > from1)) || (!move && (to1 < from1))) && !(board[from1][from2] >= 'A' && board[from1][from2] <= 'Z'))
                  {
                    JOptionPane.showMessageDialog(null, "Can't move backwards without a king", "Illegal move! - " + TITLE, 0);
                  }
                  else if (to1 > SIZE || to2 > SIZE || to1 < 0 || to2 < 0 || (!move && to1 != from1 + 1) || (move && to1 != from1 - 1) || (to2 != from2 + 1 && to2 != from2 - 1))
                  {
                    if (board[(to1 + from1) / 2][(to2 + from2) / 2] == notMark && board[to1][to2] == EMPTY)
                    {
                      JOptionPane.showMessageDialog(null, "You've taken a \"" + board[(to1 + from1) / 2][(to2 + from2) / 2] + "\"!", header + " - " + TITLE, 2);
                      board[to1][to2] = board[from1][from2];
                      board[from1][from2] = EMPTY;
                      board[(to1 + from1) / 2][(to2 + from2) / 2] = EMPTY;
                      
                      notPiece--;
                      
                      if (notPiece == 0)
                        winner = true;
                      
                      checkKing();
                    
                      break;
                    }
                    else if((board[from1][from2] >= 'A' && board[from1][from2] <= 'Z') && ((move && to1 < from1) || (!move && to1 > from1)))
                    {
                      board[to1][to2] = board[from1][from2];
                      board[from1][from2] = EMPTY;
                      //System.out.println("King-only move made");/////////////////////////////////////////////////////////////TESTING CODE
                      break;
                    }
                    else
                    {
                      //System.err.print("I'm sorry, but you can't place it there. Try finding somewhere else to place your \"" + mark + "\". If you're sure that you can place your \"" + mark + "\" at " + spareStr + ", be sure that it is typed like this: \"Letter Number\", with only a space between them (Example: \"A 1\").\n  ");
                      JOptionPane.showMessageDialog(null, "I'm sorry, but you can't place it there. Try finding somewhere else to place your \"" + board[from1][from2] + "\".\nIf you're sure that you can place your \"" + mark + "\" at " + spareStr + ", be sure that it is typed like this: \"Letter Number\", with only a space between them (Example: \"A 1\").", "Error - " + TITLE, 0);
                    }
                  }
                  else if (board[to1][to2] != EMPTY)
                  {
                    //System.err.print("I'm sorry, but there's already a piece there. Try finding somewhere else to place your \"" + mark + "\".\n  ");
                    JOptionPane.showMessageDialog(null, "I'm sorry, but there's already a \"" + board[to1][to2] + "\" there. Try finding somewhere else to place your " + color + " piece.", "Illegal move! - " + TITLE, 0);
                  }
                  else
                  {
                    board[to1][to2] = board[from1][from2];
                    board[from1][from2] = EMPTY;
                    checkKing();
                    break;
                  }
                }
              }
            }
          }
          if (move)
          {
            pieces1 = piece;
            pieces2 = notPiece;
          }
          else
          {
            pieces2 = piece;
            pieces1 = notPiece;
          }
          move = !move;
          //END PLAYER TURN
        }
      }
      //END GAME
      move = !move;
      
      System.out.print(GameBoard.print(SIZE, board));
      
      //BEGIN FINAL STATEMENT
      header = "Game over";
      if (turns == ((SIZE * SIZE) - 1) && !winner)
        JOptionPane.showMessageDialog(null, "Sorry... no one wins. :/", header + " - " + TITLE, 1);
      else if (!move)
      {
        JOptionPane.showMessageDialog(null, "Player 1 wins!", header + " - " + TITLE, 1);
        p1wins++;
      }
      else
      {
        JOptionPane.showMessageDialog(null, "Player 2 wins!", header + " - " + TITLE, 1);
        p2wins++;
      }
      
      System.out.println("\n SCORE: \n" + 
                         " " + mark1 + " | " + mark2 + "\n" + 
                         "---+---");
      if (p1wins < 9)
        System.out.print(" " + p1wins + " ");
      else if (p1wins < 99)
        System.out.print(" " + p1wins);
      else
        System.out.print(p1wins);
      System.out.print("|");
      if (p2wins < 9)
        System.out.print(" " + p2wins + " ");
      else if (p2wins < 99)
        System.out.print(" " + p2wins);
      else
        System.out.print(p2wins);
      System.out.println("\n   |\n");
      
      if (!YesNoBox.bool("Would you like to play again?", TITLE, 3))
      {
        if (YesNoBox.bool("Would you like to save your score?", TITLE, 3))
        {
          try
          {
            GameScore.tryScore(SAVEFILE, JOptionPane.showInputDialog("What is Player 1's username?"), p1wins, p2wins);
            GameScore.tryScore(SAVEFILE, JOptionPane.showInputDialog("What is Player 2's username?"), p2wins, p1wins);
          }
          catch(java.io.IOException ex)
          {
            System.err.println("No file named \"" + SAVEFILE + "\" in this directory.");
          }
        }
        if (YesNoBox.bool("Would you like to see the scoreboard?", TITLE, 3))
        {
          try
          {
            System.out.println(GameScore.topScores(SAVEFILE, 5));
            JOptionPane.showMessageDialog(null, GameScore.topScores(SAVEFILE, 5));
          }
          catch(java.io.IOException ex)
          {
            System.err.println("No file named \"" + SAVEFILE + "\" in this directory.");
          }
        }
        
        break;
      }
      else
      {
        quit = false;
      }
      
      winner = false;
      
      //END FINAL STATEMENT
    }
    System.err.println("Program Teminated");
  }
  
  //USEFUL METHODS
  private static void checkKing()
  {
    if ((to1 == 0 || to1 == SIZE-1) && (board[to1][to2] >= 'a' && board[to1][to2] <= 'z'))
    {
      board[to1][to2] = (char)(mark - 32);
      JOptionPane.showMessageDialog(null, "You've been kinged! (kings are represented by capital letters)", "Kinged! - " + TITLE, 2);
    }
  }
}